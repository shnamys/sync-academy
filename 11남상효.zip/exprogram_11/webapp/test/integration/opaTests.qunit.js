/* global QUnit */

sap.ui.require(["exam/exprogram11/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
