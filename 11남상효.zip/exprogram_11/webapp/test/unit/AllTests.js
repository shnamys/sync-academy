sap.ui.define([
	"exam/exprogram_11/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
