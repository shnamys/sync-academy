sap.ui.define([
	"exam/exprogram_00/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
